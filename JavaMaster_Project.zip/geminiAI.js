// ═══════════════════════════════════════════════════════════════
// GEMINI AI SERVICE — Calls backend API (API key stays secure on server)
// ═══════════════════════════════════════════════════════════════

const BACKEND_URL = 'http://localhost:3001/api/chat';

/**
 * Call backend which proxies to Gemini API
 * @param {string} userMessage - The user's question
 * @param {Array} chatHistory - Previous messages for context [{role, content}]
 * @param {string} topicContext - Current topic name for tailored responses
 * @returns {Promise<string>} - The AI response in Markdown
 */
export async function askGemini(userMessage, chatHistory = [], topicContext = null) {
  try {
    // Build messages array with history + current message
    const messages = [
      ...chatHistory.map(msg => ({
        role: msg.role === 'assistant' ? 'assistant' : 'user',
        content: msg.content
      })),
      { role: 'user', content: userMessage }
    ];

    const body = { messages };
    if (topicContext) body.topicContext = topicContext;

    const response = await fetch(BACKEND_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('Backend API error:', response.status, errorData);
      return null;
    }

    const data = await response.json();
    return data?.reply || null;
  } catch (error) {
    console.error('Backend API call failed:', error.message);
    return null;
  }
}

export default askGemini;
