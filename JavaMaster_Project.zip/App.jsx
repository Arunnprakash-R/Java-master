import { useState, useEffect, useCallback } from 'react';
import { SYLLABUS } from './data/syllabus';
import { useChat } from './hooks/useChat';
import { useProgress } from './hooks/useProgress';
import Sidebar from './components/Sidebar';
import HomeView from './components/HomeView';
import ChatWindow from './components/ChatWindow';
import styles from './App.module.css';

export default function App() {
  const [activeTopic, setActiveTopic] = useState(null);
  const [activeUnit, setActiveUnit] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth > 768);
  const [initialQuestion, setInitialQuestion] = useState(null);

  const {
    toggleTopic,
    isCompleted,
    getUnitProgress,
    overallProgress,
    completedCount,
    unitsCompleted,
    resetProgress,
    completedTopics,
  } = useProgress();

  const { messages, isLoading, send, switchTopic } = useChat(activeTopic, activeUnit);

  // Listen for reset progress event from sidebar
  useEffect(() => {
    const handler = () => resetProgress();
    window.addEventListener('resetProgress', handler);
    return () => window.removeEventListener('resetProgress', handler);
  }, [resetProgress]);

  // Handle window resize for sidebar
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) {
        setSidebarOpen(true);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleSelectTopic = useCallback((unit, topic, question = null) => {
    setActiveUnit(unit);
    setActiveTopic(topic);
    setInitialQuestion(question);
    switchTopic(topic.id);
  }, [switchTopic]);

  const handleGoHome = useCallback(() => {
    setActiveTopic(null);
    setActiveUnit(null);
    setInitialQuestion(null);
  }, []);

  const toggleSidebar = useCallback(() => {
    setSidebarOpen((prev) => !prev);
  }, []);

  const isHome = !activeTopic;

  return (
    <div className={styles.appLayout}>
      <Sidebar
        syllabus={SYLLABUS}
        activeTopic={activeTopic}
        onSelectTopic={handleSelectTopic}
        onGoHome={handleGoHome}
        completedTopics={completedTopics}
        isOpen={sidebarOpen}
        onToggle={toggleSidebar}
        getUnitProgress={getUnitProgress}
        isHome={isHome}
      />

      <div className={styles.mainArea}>
        <div className={styles.topBar}>
          <button
            className={styles.hamburger}
            onClick={toggleSidebar}
            aria-label={sidebarOpen ? 'Close sidebar' : 'Open sidebar'}
          >
            ☰
          </button>
          <span className={styles.topBarTitle}>
            <span className={styles.topBarTitleAccent}>JavaMaster</span>
            {activeTopic && (
              <> — {activeUnit?.title} › {activeTopic.title}</>
            )}
          </span>
        </div>

        <div className={styles.content}>
          {isHome ? (
            <HomeView
              overallProgress={overallProgress}
              completedCount={completedCount}
              unitsCompleted={unitsCompleted}
              getUnitProgress={getUnitProgress}
              onSelectTopic={handleSelectTopic}
            />
          ) : (
            <ChatWindow
              unit={activeUnit}
              topic={activeTopic}
              messages={messages}
              isLoading={isLoading}
              onSend={send}
              isCompleted={isCompleted(activeTopic.id)}
              onToggleComplete={toggleTopic}
              getUnitProgress={getUnitProgress}
              initialQuestion={initialQuestion}
              onClearInitialQuestion={() => setInitialQuestion(null)}
            />
          )}
        </div>
      </div>
    </div>
  );
}
